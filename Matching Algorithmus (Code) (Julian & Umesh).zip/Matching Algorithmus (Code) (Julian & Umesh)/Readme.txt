1 Graphen: enthällt den Code zur Erstellung von Graphen der Studenten-Umfrage und die daraus resultierenden Graphen
2 Kaggle: enthällt den Code Zur Erstellung und Aufbereitung des Bewerberdatensatzes aus Kaggle, sowie das hinzufügen der Arbeitsstellen und das heuristiche matchen von Personen un der Arbeitsplätze
3 Linkedin Webscraper: enthällt den Code zum scrapen von Linkedin Profilen  